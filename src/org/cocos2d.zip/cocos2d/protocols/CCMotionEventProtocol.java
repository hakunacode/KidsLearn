package org.cocos2d.protocols;

import android.view.MotionEvent;

public interface CCMotionEventProtocol
{
	void onTouch(MotionEvent e);
}
