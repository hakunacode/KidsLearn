package org.cocos2d.utils;

import android.view.MotionEvent;

public class Util5 {
	public static int getPointerId(MotionEvent event, int pid) {
		return event.getPointerId(pid);
	}
}
