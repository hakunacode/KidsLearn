package org.cocos2d.opengl;

public class OpenGLViewAlreadyAttachedException extends Exception {
    public OpenGLViewAlreadyAttachedException(String reason) {
        super(reason);
    }
}
